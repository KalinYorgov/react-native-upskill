export const ICON_NAMES = {
    HOME: 'home-outline',
    ACCOUNT: 'person-outline',
    CART: 'cart-outline',
    ERROR: 'alert-circle-outline',
    MEN: 'man-outline',
    WOMEN: 'woman-outline',
    HELP: 'help-circle-outline',
} as const;

