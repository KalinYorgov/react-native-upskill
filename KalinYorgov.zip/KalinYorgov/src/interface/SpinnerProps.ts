export interface SpinnerProps {
    size?: 'small' | 'large';
    color?: string;
    fullScreen?: boolean;
}
