export interface ErrorProps {
    message: string;
}
