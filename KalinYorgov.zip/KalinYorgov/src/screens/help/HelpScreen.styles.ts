import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
    content: {
        padding: 16,
    },
    title: {
        marginBottom: 16,
    },
});
